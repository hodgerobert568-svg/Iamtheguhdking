// server.js
require('dotenv').config();
const express = require('express');
const nodemailer = require('nodemailer');
const path = require('path');
const fs = require('fs');

const app = express();
app.use(express.json());

const SECRET = process.env.SEND_SECRET || 'change-this-secret';
const PDF_PATH = path.join(__dirname, 'public', 'BSFREENATION_Final_Package.pdf');

const RECIPIENTS = {
  tx: [
    'alopez@liftfund.com',
    'ktorres@peoplefund.org',
    'menkir@allianceontheweb.org',
    'info@altcap.org'
  ],
  sc: [
    'loans@ascendus.org',
    'info@ascendus.org',
    'sbac@sbacsav.com',
    'info@climbfund.org',
    'kate@climbfund.org'
  ]
};

const SUBJECT = 'BSFREENATION – Rehabilitation and Beautification Initiative';
const BODY_TEXT = `Dear Recipient,

Please find attached the BSFREENATION – Rehabilitation and Beautification Initiative proposal for your review.

We look forward to the opportunity to collaborate on this important environmental restoration and community improvement effort.

Sincerely,
Robert Hodge
Operating Manager
BSFREENATION`;

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.mail.yahoo.com',
  port: Number(process.env.SMTP_PORT || 465),
  secure: true,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
});

app.get('/', (req, res) => {
  res.send('BSFREENATION send service running');
});

app.all('/send', async (req, res) => {
  try {
    const token = req.get('x-send-token');
    if (!token || token !== SECRET) {
      return res.status(401).json({ ok: false, error: 'Unauthorized' });
    }
    const target = (req.query.target || req.body.target || '').toLowerCase();
    if (!['tx','sc','both'].includes(target)) {
      return res.status(400).json({ ok:false, error: 'target must be tx, sc, or both' });
    }
    let toList = [];
    if (target === 'tx') toList = RECIPIENTS.tx;
    if (target === 'sc') toList = RECIPIENTS.sc;
    if (target === 'both') toList = [...new Set([...RECIPIENTS.tx, ...RECIPIENTS.sc])];
    if (!fs.existsSync(PDF_PATH)) {
      return res.status(500).json({ ok:false, error: 'PDF not found on server' });
    }
    const mailOptions = {
      from: `"BSFREENATION" <${process.env.SMTP_USER}>`,
      to: toList.join(','),
      subject: SUBJECT,
      text: BODY_TEXT,
      attachments: [
        {
          filename: 'BSFREENATION_Final_Package.pdf',
          path: PDF_PATH,
          contentType: 'application/pdf'
        }
      ]
    };
    const info = await transporter.sendMail(mailOptions);
    return res.json({ ok: true, info });
  } catch (err) {
    console.error('Send error', err);
    return res.status(500).json({ ok:false, error: err.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server listening on ${PORT}`));
